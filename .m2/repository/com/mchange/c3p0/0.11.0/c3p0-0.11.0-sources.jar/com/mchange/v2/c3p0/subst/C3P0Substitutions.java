package com.mchange.v2.c3p0.subst;

public final class C3P0Substitutions
{
    public final static String VERSION    = "0.11.0";
    public final static String DEBUG      = "true";
    public final static String TRACE      = "10";
    public final static String TIMESTAMP  = "2025-04-23T19:34:19.488136Z";

    private C3P0Substitutions()
    {}
}
